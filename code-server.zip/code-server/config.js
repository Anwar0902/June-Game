const Config = {
  // app configuration
  APP_CONFIG: {
    CORS: {
      EXPOSE_HEADERS: ['WWW-Authenticate', 'Server-Authorization'],
      MAX_AGE: 5,
      CREDENTIALS: true,
      ALLOWED_METHODS: ['GET', 'POST', 'PUT', 'HEAD', 'DELETE', 'OPTIONS'],
      ALLOWED_HEADERS: ['X-Requested-With', 'X-HTTP-Method-Override', 'Content-Type', 'Accept', 'userSessionId', 'source', 'platform','x-frame-options', 'udchalotoken', 'token']
    }
  },
  API_METHOD: {
    GET: 'get',
    PUT: 'put',
    POST: 'post'
  },

  // aws configurations
  AWS_AUTH: {
    REGION: 'ap-south-1'
  },
  REDIS_AUTH: {
    PORT: `${process.env.UDCHALO_REDIS_PORT}`,
    HOST: `${process.env.UDCHALO_REDIS_HOST}`,
    ENABLE_OFFLINE_QUEUE: true,
    PASSWORD : null
  }
}

module.exports = Config