const koa = require('koa') // Koa framework - http://koajs.com/
const CONFIG = require('./config')
const router = require('./src/router') // Business services endpoints
const cors = require('kcors') // Enable cross origin HTTP requests
const koaBody = require('koa-body')(({ multipart: true}))
const session = require('koa-generic-session') // koa session to manage sessions
const redisStore = require('koa-redis')

const REDIS_HOST = CONFIG.REDIS_AUTH.HOST
const REDIS_PORT = CONFIG.REDIS_AUTH.PORT

const app = new koa()

// set allowed origins only
var corsOptions = {
  origin: 'http://localhost:5500',
  optionsSuccessStatus: 200 // For legacy browser support
}
app.use(cors(corsOptions))
app.use(koaBody)
// Sessions
app.use(session({
  store: redisStore({
    host: REDIS_HOST,
    port: REDIS_PORT,
  }),
  cookie: { domain: 'localhost', maxAge: 15552000/* , path: "/api" */ },
  key: '_09dfbb',
  maxAge: 15552000,
  renew: true,
  ttl: 15552000,
  rolling: false
}, app))


// routes
app.use(router.routes())
app.use(router.allowedMethods())

// start server
app.listen(5501, () => {
  console.log("server running on port 5501");
})
