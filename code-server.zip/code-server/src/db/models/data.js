const validator = require('joi')
const messages = require('../../message')
const { validMessage } = messages

const stringValidator = validator.string()
const numberValidator = validator.number()


module.exports = {
  sessionId: stringValidator.required().options(validMessage('sessionId')),
  name: stringValidator.required().options(validMessage('name')),
  score: numberValidator.required().options(validMessage('score')),
  id: stringValidator.required().options(validMessage('id'))
}
