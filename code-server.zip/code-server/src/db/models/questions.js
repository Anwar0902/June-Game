const validator = require('joi')
const messages = require('../../message')
const { validMessage } = messages

const stringValidator = validator.string()
const numberValidator = validator.number()
const arrayValidator = validator.array()


module.exports = {
  id: stringValidator.required().options(validMessage('id')),
  question: stringValidator.required().options(validMessage('question')),
  options: arrayValidator.required().options(validMessage('options')),
  answer: arrayValidator.required().options(validMessage('answer')),
  isEnable: numberValidator.required().options(validMessage('isEnable'))
}
