const { DB }  = require('../db')
const _ = require('lodash')

const models = require('../models')

module.exports = DB.define('Question', {
  hashKey: 'id',
  timestamps : true,
  schema : models.questions,
  indexes: [
    { hashKey: 'isEnable', name: 'isEnable', type: 'global' }
  ],
  tableName: 'questions_dev'
})
