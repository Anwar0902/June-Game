const { DB }  = require('../db')
const _ = require('lodash')

const models = require('../models')

module.exports = DB.define('Data', {
  hashKey: 'sessionId',
  rangeKey: 'id',
  timestamps : true,
  schema : models.payment,
  tableName: 'data_dev'
})
