const DB  = require('dynogels')
const CONFIG = require('../../config')

// db setup
DB.AWS.config.update({
  region: CONFIG.AWS_AUTH.REGION
})

module.exports = {
  DB,
  CONFIG
}
