const Question = require('../../data/questions')

function getQuestions() {
  return new Promise((resolve, reject) => {
    Question.query(1)
      .usingIndex('isEnable')
      .exec((err, res)=>{
        if(err){
          reject(err)
        } 
        if(res){
          const response = JSON.parse(JSON.stringify(res.Items))
          resolve(response)
        }
        resolve(null)
      })
  })
}

module.exports = {
  getQuestions
}
