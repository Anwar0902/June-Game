const Data = require('../../data/data')

function save(payload){
  return new Promise((resolve, reject) => {
    Data.create(payload, (err, res) => {
      if(err){
        reject(err)
      } 
      if(res){
        resolve(res.attrs)
      }
      resolve(null)
    })
  })
}

function update(payload){
  return new Promise((resolve, reject)=>{
    Data.update(
      payload,
      { expected: { sessionId: { Exists: true }, id: { Exists: true } } },
      (err, res) => {
        if(err){
          reject(err)
        } 
        if(res) {
          resolve(res.attrs)
        }
        resolve(null)
      }
    )
  })
}

function getLeaderBoard(sessionId) {
  return new Promise((resolve, reject) => {
    Data.query(sessionId)
      .exec((err, res)=>{
        if(err){
          reject(err)
        } 
        if(res){
          const payment = JSON.parse(JSON.stringify(res.Items))
          resolve(payment)
        }
        resolve(null)
      })
  })
}

module.exports = {
  save,
  update,
  getLeaderBoard
}
