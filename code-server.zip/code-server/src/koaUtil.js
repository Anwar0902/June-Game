const _ = require('ramda')
const uuid = require('uuid/v4');
const Console = require('./logger/winston')

const HTTPResponse = (status, body) => {
  return {
    status,
    body: body ? body : null
  }
}

// to return response with status 200
const OK = (response) => {
  return HTTPResponse(200, response)
}

function wrapHandler(handler, excludeLogPaths) {
  return async (ctx, next) => {
    const ip = ctx.request.ip
    try {
      const body = { ...ctx.request.body, endUserIp: ip }
      const url = ctx.request.url
      Console.info(`Requested url :- ${url} and Requested method:- ${ctx.request.method}`);
      _.equals(ctx.request.method, 'POST') ? Console.info(`Requested payload :- ${JSON.stringify(body)}`) : '';
      const response =  _.equals(ctx.request.method, 'POST') ? await handler(body, ctx, await next()) : await handler(ctx, await next())
      if (response && response.redirect)
        ctx.redirect(response.redirect)
      if(response) {
        for (const key in response)
          ctx[key] = response[key]
        Console.info(`Response payload :- ${JSON.stringify(response)}`);
      }
    } 
    catch (err) {
      Console.info(`Response error :- ${JSON.stringify(err)}`);
      ctx.status = err.statusCode || 500
      ctx.body = {
        success: false,
        message: err.message,
      }
    }
  }
}

const wrapHandlerModule = (module, excludePaths) =>  _.fromPairs( _.map(([name, fun]) => [name, wrapHandler(fun, excludePaths)], _.toPairs(module)))


function randomString() {
  return uuid()
}

module.exports = {
  randomString,
  wrapHandlerModule,
  OK
}
