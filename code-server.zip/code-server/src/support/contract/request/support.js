const messages = require('../../../message')
const validator = require('joi')
const { validMessage } = messages

const objectValidator = validator.object()
const stringValidator = validator.string()
const numberValidator = validator.number()

const support = objectValidator.keys({
  sessionId: stringValidator.required().options(validMessage('sessionId')),
  id: stringValidator.required().options(validMessage('id')),
  score: numberValidator.required().options(validMessage('score'))
})

module.exports = {
    support
}