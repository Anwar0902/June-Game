const Router = require('koa-router')
const { wrapHandlerModule } = require('../koaUtil')
const handler = wrapHandlerModule(require('./handler'))
const {support} = require('./contract/request/support')
const validator = require('joi')
const _ = require('lodash')

const router = new Router()

function isValid(contract) {
    return async (ctx, next) => {
        const result = validator.validate(ctx.request.body, contract, { abortEarly: true })
        if (!_.isNull(result.error)) {
            ctx.body = result.error.details
            ctx.status = 400
            const module1 = ctx.originalUrl.split('/')[2]
            const env = process.env.NODE_ENV
            const ip = ctx.request.ip
            const url = ctx.request.header && `${ctx.request.header.host}${ctx.request.url}` || ctx.originalUrl
            const urlData = ctx.originalUrl.split('/')
            const title = urlData[2] + " " + urlData[3]
            // logger.logException(JSON.stringify(result.error.details), JSON.stringify(ctx.request.body), HIGH_SEVERITY, "joi validation error", title, ERROR, module1, env, 'uc-server', null, null, ctx.request.header.usersessionid, ip, null, url, null, null, JSON.stringify(result.error))
        } else {
            ctx.body = result.value
            await next()
        }
    }
}

router.get('/getData/:name', handler.createSession)
router.get('/leaderBoard/:sessionId', handler.leaderBoard)
router.get('/questions/:sessionId', handler.getQuestions)
router.post('/update', isValid(support), handler.updateScore)
module.exports = router
