const { OK, randomString } = require('../koaUtil')
const cache = require('../cache/redis')
const Data = require('../db/services/data/data');
const Question = require('../db/services/data/questions');
const data = require('../db/models/data');


async function createSession(ctx) {
  const name = ctx.params.name;
  const date = new Date();
  const hour = date.getHours();
  let min = date.getMinutes();
  min -= min % 2;
  const key = `${hour}_${min}`;
  let cacheResponse = await cache.get(key);
  let time = cacheResponse && cacheResponse.time;
  if(!time) {
    const cachePayload = {
      time: date,
      questions: []
    }
    await cache.put(key, cachePayload, 60*2);
    time = date;
  }
  const payload = {
    sessionId: key,
    name,
    score: 0,
    id: randomString()
  }
  const response = await Data.save(payload)
  if(!response) {
    return OK({
      success: false,
      message: 'Unable to create session!',
      response: null
    })
  }
  return OK({
    success: true,
    message: 'Session created successfully',
    response : {
      sessionId: key,
      time,
      name,
      id: payload.id
    }
  })
}

async function leaderBoard(ctx) {
  const session = ctx.params.sessionId;
  const response = await Data.getLeaderBoard(session);
  response.sort((data1, data2) => {
    return data1.score >= data2.score ? -1 : 1;
  })
  if(!response) {
    return OK({
      success: false,
      message: 'Unable to load Leaderboard!',
      response: null
    });
  }
  return OK({
    success: true,
    message: 'Successfully load Leaderboard!',
    response
  })
}

async function getQuestions(ctx) {
  const session = ctx.params.sessionId;
  const cacheResponse = await cache.get(session);
  if (!cacheResponse) {
    return OK({
      success: false,
      message: 'Unable to load questions!',
      response: null
    })
  }
  let response = cacheResponse && cacheResponse.questions;
  if (response && response.length === 0) {
    response = await Question.getQuestions();
    response = response.slice(0,10);
    const cachePayload = {
      time: cacheResponse.time,
      questions: response
    }
    await cache.put(session, cachePayload, 60 * 2);
  }
  if(!response) {
    return OK({
      success: false,
      message: 'Unable to load questions!',
      response: null
    })
  }
  return OK({
    success: true,
    message: 'Successfully load questions!',
    response: response
  })
}

async function updateScore(body, ctx) {
  const payload = {
    sessionId: body.sessionId,
    id: body.id,
    score: body.score
  }
  const response = await Data.update(payload)
  if (!response) {
    return OK({
      success: false,
      message: 'Unable to update score!',
      response: null
    })
  }
  return OK({
    success: true,
    message: 'Successfully updated score!',
    response
  })
}

module.exports = {
  createSession,
  leaderBoard,
  getQuestions,
  updateScore
};
