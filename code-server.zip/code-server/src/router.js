const Router = require('koa-router')
const router = new Router()

// support routes
const supportRouter = require('./support/router')

// for support routes
router.use(supportRouter.routes(), supportRouter.allowedMethods())

module.exports = router
