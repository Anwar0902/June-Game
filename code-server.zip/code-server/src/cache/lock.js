const { client } = require('./redis')
const lock = promisify(require('redis-lock')(client))

module.exports = lock
