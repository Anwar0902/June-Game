const redis = require('redis')
const CONFIG = require('../../config')
const Console = require('../logger/winston')

// create client
const client = redis.createClient({
  port: CONFIG.REDIS_AUTH.PORT,
  host: CONFIG.REDIS_AUTH.HOST,
  enable_offline_queue : CONFIG.REDIS_AUTH.ENABLE_OFFLINE_QUEUE,
  retry_strategy:  (options) => {
    if (options.error && options.error.code === 'ECONNREFUSED') {
      // end reconnecting on a specific error and flush all commands with a individual error
      return new Error('The server refused the connection')
    }
    if (options.total_retry_time > 1000 * 60 * 60) {
      // end reconnecting after a specific timeout and flush all commands with a individual error
      return new Error('Retry time exhausted')
    }
    if (options.attempt > 10) {
      // end reconnecting with built in error
      return 'undefined'
    }
    // reconnect after
    return Math.min(options.attempt * 100, 3000)
  }
})
const lock = require('redis-lock')(client)

// auth redis client in case of passsword
if (CONFIG.REDIS_AUTH.PASSWORD != null) {
  client.auth(CONFIG.REDIS_AUTH.PASSWORD, (err, reply) => {
    if(err){
      Console.info('Auth Error: ', err)
    } else if(reply == 'OK') {
      Console.info('Auth Successfull')
    }
  })
}

// On successfull connection
client.on('connect', () => {
  Console.info('Redis Connected Successfully')
})

// On error in case of connection
client.on('error', () =>{
  Console.info('Connection Error Reddis')
})

// add key, value to cache
function put(key, value, interval = 300) {
  try{
    return new Promise((resolve, reject) => {
      client.set(key, JSON.stringify(value), 'EX', parseInt(interval), (err, res) => {
        if(err){
          reject(err)
        } else if(res == 'OK'){
          resolve(res)
        }
      })
    })
  } 
  catch(error){
    Console.info(`Cache put error for key ${key} and value ${value}`);
  }
}

// get value corresponding to key
function get(key, interval) {
  try{
    return new Promise((resolve, reject) => {
      client.exists(key, (err, res)  => {
        if (res === 1) {
          // if key exists get value
          client.get(key, (err, res) => {
            if(err){
              reject(err)
            } else if(res){
              resolve(JSON.parse(res))
            }
          })
        } else {
          resolve(null)
        }
      })
    })
  } 
  catch(error){
    Console.info(`Cache get error for key ${key}`);
  }
}


// delete a particular key
function del(key, interval) {
  try{
    return new Promise((resolve, reject) => {
      client.exists(key, (err, res)  => {
        if (res === 1) {
          // if key exists get value
          client.del(key, (err, res) => {
            if(err){
              reject(err)
            } else if(res){
              resolve(res)
            }
          })
        } else {
          resolve(null)
        }
      })
    })
  } 
  catch(error){
    Console.info(`Cache delete error for key ${key}`);
  }
}

// expire particular key
function expire(key, time, interval){
  try{
    return new Promise((resolve, reject) => {
      // check if key exists
      client.exists(key, (err, res)  => {
        if (res === 1) {
          // if key exists expire key
          client.expire(key, time, (err, res) =>{
            if(err){
              reject(err)
            } else if(res){
              resolve(res)
            }
          })
        } else {
          resolve(null)
        }
      })
    })
  } 
  catch(error){
    Console.info(`Cache expire error for key ${key} and value ${value}`);
  }
}

// get all keys present in cache
function keys(interval){
  try{
    return new Promise((resolve, reject) => {
      client.keys('*', (err, res)=>{
        if(err){
          reject(err)
        } else if(res.length>0) {
          resolve(res)
        } else {
          resolve(null)
        }
      })
    })
  } 
  catch(error){
    Console.info(`Cache keys error for key ${key}`);
  }
}

// clear all cache
function clear(interval) {
  try{
    return new Promise((resolve, reject) => {
      client.flushall((err, res)=>{
        if(err){
          reject(err)
        } else {
          resolve(res)
        }
      })
    })
  } 
  catch(error){
    Console.info(`Cache clear error`);
  }
}

module.exports = {
  put,
  get,
  del,
  expire,
  keys,
  clear,
  lock
}
