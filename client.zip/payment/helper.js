

function showHideElement(element, action) {
    element.style.display = action;
}

function addLoader(loaderText, element) {
    var newDiv = document.createElement('div');
    newDiv.id = "loaderDiv";
    newDiv.className = "loaderDiv";
    newDiv.innerHTML = addLoaderHtml(loaderText);
    if (element === 'body')
        document.getElementsByTagName(element)[0].appendChild(newDiv);
    else
        document.getElementById(element).appendChild(newDiv);
}

function addLoaderHtml(loaderText) {
    return ' <div class="loader"></div> \
        <p class="loaderText">' + loaderText + '</p> \
    '
}

function removeLoader() {
    document.getElementById('loaderDiv').remove();
}

function isHtml(htmlData) {
    return /<\/?[a-z][\s\S]*>/i.test(htmlData);
}

function changeProcessingText(element, text, event) {
    element.innerHTML = text;
    element.style.pointerEvents = event;
    document.getElementsByTagName('body')[0].style.pointerEvents = event;
}

function toaster(action, title, msg) {
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-center",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
    toastr[action](msg, title)
}