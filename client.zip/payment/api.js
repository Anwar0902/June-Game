function makeRequest(method, url, data, token) {
    return new Promise(function (resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open(method, url, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        // xhr.withCredentials = true;
        xhr.onload = function (e) {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    if( isHtml(xhr.responseText) ) {
                        resolve(xhr.responseText);
                    } else {
                        const responseObj = JSON.parse(xhr.responseText);
                        if(responseObj && responseObj.success === false) {
                            toaster('error', 'Error', responseObj.message );
                        }
                        if (responseObj && responseObj.redirectLink) {
                            sendResponseToParent(responseObj.redirectLink);
                        }
                        resolve(responseObj);
                    }
                }
            }
        };
        xhr.onerror = function (e) {
            const responseObj = {
                success: false,
                isError: true,
                message: 'Unknown Error!'
            }
            toaster('error', 'Error', responseObj.message);
            resolve(responseObj);
        };
        method === 'POST' ? xhr.send(JSON.stringify(data)) : xhr.send();
    });
}

async function loginApi(name) {
    const url = `${baseUrl}getData/${name}`;
    const result = await makeRequest('GET', url);
    return result;
}

async function questionApi(sessionId) {
    const url = `${baseUrl}questions/${sessionId}`;
    const result = await makeRequest('GET', url);
    return result;
}

async function updateApi(payload) {
    const url = `${baseUrl}update`;
    const result = await makeRequest('POST', url, payload);
    return result;
}

async function leaderBoardApi(sessionId) {
    const url = `${baseUrl}leaderBoard/${sessionId}`;
    const result = await makeRequest('GET', url);
    return result;
}