let baseUrl = 'http://localhost:5501/';
let pages = ['gameModesPage', 'questionPage', 'leaderBoardPage', 'reviewScore'];

window.onload = async function () {
    hideForms();
    document.getElementById('gameModesPage').style.display = "block";
}

function removeAllChildNodes(parent) {
    while (parent.firstChild) {
        parent.removeChild(parent.firstChild);
    }
}

function focusLoginId() {
    document.getElementById('loginId').classList.add('focusText');
}

function blurLoginId() {
    document.getElementById('loginId').classList.remove('focusText');
}



// new code

let isLoginErrorAdded = false;
let remainingTime = 300;
let totalTime = 300;
let minutes = 5;
let seconds = 0;
let sessionId;
let setIntervalId;
let halfTime = false;
let progressValue = 0;
let qcount = 0;
let score = 0;
let isFirstQuestion = true;
let tim = 30;
let id;
let userName;
let attempted = 0;
let questions = [
    {question: 'what is ur name', options: ['anwar', 'baba', 'jaja', '1'], answer: '0'},
    { question: 'what is ur pet', options: ['wwww', 'baba', 'jaja', '2'], answer: '0' },
    { question: 'what is ur cat', options: ['anwddddddddar', 'baba', '3', 'jajaa'], answer: '0' },
    { question: 'what is ur chat', options: ['rrrttt', 'baba', 'jaja', '4'], answer: '0' },
    { question: 'what is ur name', options: ['anwar', 'baba', 'jaja', '1'], answer: '0' },
    { question: 'what is ur pet', options: ['wwww', 'baba', 'jaja', '2'], answer: '0' },
    { question: 'what is ur cat', options: ['anwddddddddar', 'baba', '3', 'jajaa'], answer: '0' },
    { question: 'what is ur chat', options: ['rrrttt', 'baba', 'jaja', '4'], answer: '0' },
    { question: 'what is ur name', options: ['anwar', 'baba', 'jaja', '1'], answer: '0' },
    { question: 'what is ur pet', options: ['wwww', 'baba', 'jaja', '2'], answer: '0' },
    { question: 'what is ur cat', options: ['anwddddddddar', 'baba', '3', 'jajaa'], answer: '0' },
    { question: 'what is ur chat', options: ['rrrttt', 'baba', 'jaja', '4'], answer: '0' }
]

let leaderBoardData = [
    {name: 'anwar', score: '1'},
    {name: 'baba', score: '2'},
    { name: 'anwar', score: '1' },
    { name: 'baba', score: '2' },
    { name: 'anwar', score: '1' },
    { name: 'baba', score: '2' },
    { name: 'anwar', score: '1' },
    { name: 'baba', score: '2' },
    { name: 'anwar', score: '1' },
    { name: 'baba', score: '2' },
    { name: 'anwar', score: '1' },
    { name: 'baba', score: '2' },
    { name: 'anwar', score: '1' },
    { name: 'baba', score: '2' },
    { name: 'anwar', score: '1' },
    { name: 'baba', score: '2' }
]

async function login() {
    const name = document.getElementById("loginId").value;
    if(name.length < 5) {
        return;
    }
    const loginBtn = document.getElementById('loginBtn')
    changeProcessingText(loginBtn, 'LOGGING...', 'none')
    const response = await loginApi(name);
    changeProcessingText(loginBtn, 'LOGIN', 'auto')
    if(!response.success) {
        toaster('error', 'Error', response.message);
        return;
    }
    document.getElementById('gameModesPage').style.display = "none";
    const date = new Date();
    remainingTime = totalTime - Math.floor((date - (new Date(response.response.time))) / 1000) -1;
    tim = remainingTime % 30;
    if(tim < 29) {
        isFirstQuestion = false;
    }
    console.log(Math.floor((date - (new Date(response.response.time))) / 1000))
    sessionId = response.response.sessionId;
    id = response.response.id;
    userName = response.response.name;
    minutes = Math.floor(remainingTime / 60);
    seconds = Math.floor(remainingTime % 60);
    qcount = Math.floor((totalTime-remainingTime) / 30);
    loadQuestions();
}

async function loadQuestions() {
    addLoader('Please wait while Loading...', 'body');
    const response = await questionApi(sessionId);
    removeLoader();

    if (!response.success) {
        toaster('error', 'Error', response.message);
        document.getElementById('gameModesPage').style.display = "block";
        return;
    }
    questions = response.response;
    document.getElementById('questionPage').style.display = "block";
    if (setIntervalId)
        clearInterval(setIntervalId);
    setIntervalId = setInterval(() => {
        timerCount();
    }, 1000);
    createQuestion(qcount);
    qcount++;
}

function createQuestion(index) {

    var toAdd = document.createDocumentFragment();
    var qDiv = document.createElement('div');
    qDiv.className = "qDivQuestion";
    qDiv.innerHTML = `Q${index+1}. ${questions[index].question}`;
    toAdd.appendChild(qDiv);

    for (let i = 0; i < questions[index].options.length; i++) {
        var newDiv = document.createElement('div');
        newDiv.className = 'questionclass';
        newDiv.id = `question${i}`;
        newDiv.innerHTML = getquestionHtml(questions[index].answer, questions[index].options[i], i, index);
        toAdd.appendChild(newDiv);
    }

    document.getElementById('question').appendChild(toAdd);
}

async function saveScoreInDb() {
    const payload = {
        sessionId,
        id,
        score
    }
    await updateApi(payload);
}

async function updateScore() {
    document.getElementById('reviewScore').style.display = "none";
    addLoader('Please wait while Loading LeaderBoard...', 'body');
    const response1 = await leaderBoardApi(sessionId);
    removeLoader();
    if (!response1.success) {
        toaster('error', 'Error', response1.message);
        document.getElementById('gameModesPage').style.display = "block";
        return;
    }
    leaderBoardData = response1.response;
    leaderBoard();
}

function timerCount() {
    var element = document.getElementById("myprogressBar");
    if ((minutes === 0 && seconds === 0) || (minutes < 0 || seconds < 0)) {
        console.log("complete");
        clearInterval(setIntervalId);
        remainingTime = 0;
        document.getElementById('questionPage').style.display = "none";
        document.getElementsByTagName('body')[0].style.pointerEvents = 'auto';
        saveScoreInDb();
        reviewScore();
    }
    else {
        if (seconds === 0) {
            seconds = 59;
            minutes -= 1;
        }
        else
            seconds -= 1;
        tim = remainingTime % 30;
        console.log(remainingTime, tim);
        document.getElementById("timer").innerHTML = `00 : ${tim < 10 ? '0' : ''}${tim}`
        progressValue = (Math.round((((30 - tim) * 100) / 30)));
        element.style.width = progressValue + '%';
        console.log("dggdd", isFirstQuestion);
        if (!isFirstQuestion && (remainingTime % 30 === 29)) {
            document.getElementsByTagName('body')[0].style.pointerEvents = 'auto';
            var elem = document.getElementById('question');
            removeAllChildNodes(elem);
            createQuestion(qcount);
            qcount++;
        } else if (isFirstQuestion && (remainingTime % 30 === 29)) {
            isFirstQuestion = false;
        }
        
        remainingTime -= 1;
        if (remainingTime <= Math.floor(totalTime / 2))
            this.halfTime = true;
    }
}

function toggleLoginError() {
    if (!isLoginErrorAdded && isError) {
        addLoginError();
        isLoginErrorAdded = true;
    }
    else if ((isLoginErrorAdded && !isError)) {
        removeLoginError();
        isLoginErrorAdded = false;
    }
}

function validateLogin() {
    let loginId = document.getElementById("loginId");
    loginId.value = loginId.value.replace(/[^a-zA-z]/g, '');
    console.log(loginId.value);
    if (loginId.value.length < 5) {
        isError = true;
        toggleLoginError();
    } else {
        isError = false;
        toggleLoginError();
    }
}

function addLoginErrorHtml() {
    return '<div class="text-danger">Please enter valid Login Id</div>'
}

function addLoginError() {
    const element = document.getElementById('loginError');
    element.innerHTML = "Please enter valid Login Id";
    element.style.visibility = "visible";
}

function removeLoginError() {
    document.getElementById('loginError').style.visibility = "hidden";
}

function getquestionHtml(answer, options, index, qNumber) {
    return '<div class="flexQuestion" onclick="submitQuestion(\'' + index + '\', \'' + qNumber +'\')"> \
                <div><input type="radio" name="question" id="que'+ index + '" value="' + index + '"></div> \
                <div class="fontClass otionText">' + options + '</div>  \
            </div> \
    '
}

function getLeaderBoardHtml(name, score, index) {
    return '<div class="board"> \
                <div class="index">' + index + '</div> \
                <div class="groupNameAndScore"> \
                    <div>' + name + '</div> \
                    <div>' + score + '</div>  \
                </div> \
            </div> \
    '
}

function hideForms() {
    pages.forEach(page => {
        document.getElementById(page).style.display = "none";
    })
}

function submitQuestion(answer, qNumber) {
    attempted++;
    if (answer === questions[qNumber].answer) {
        score++;
    }
    document.getElementById(`que${answer}`).checked = true;
    document.getElementsByTagName('body')[0].style.pointerEvents = 'none';
    console.log("val", answer,score);
}

function leaderBoard() {
    document.getElementById('leaderBoardPage').style.display = "block";
    var toAdd = document.createDocumentFragment();

    for (let i = -1; i < leaderBoardData.length; i++) {
        var newDiv = document.createElement('div');
        newDiv.className = 'leader';
        newDiv.id = `leader${i}`;
        newDiv.innerHTML = i > -1 ? getLeaderBoardHtml(leaderBoardData[i].name, leaderBoardData[i].score, i+1) :
            getLeaderBoardHtml('Name', 'Score', 'Sr.')
        toAdd.appendChild(newDiv);
    }
    
    document.getElementById('leaderBoard').appendChild(toAdd);
}

function reviewScore() {
    document.getElementById('reviewScore').style.display = "block";
    var newDiv = document.createElement('div');
    newDiv.className = 'review';
    newDiv.id = `review`;
    newDiv.innerHTML = getReviewPageHtml(attempted, 10 - attempted, score);
    document.getElementById('showScore').appendChild(newDiv);
}

function getReviewPageHtml(attempted, notAttempted, score) {
    return '<div class="reviewScore"> \
                <div class="scoreStaticText"> \
                    <div>Attempted</div> \
                    <div>Not Attempted</div> \
                    <div>Score</div> \
                </div> \
                <div class="scoreStaticNumber"> \
                    <div>' + attempted + '</div> \
                    <div>' + notAttempted + '</div> \
                    <div>' + score + '</div> \
                </div> \
            </div> \
    '
}